rootProject.name = "AuroraLauncher"
include(":app")